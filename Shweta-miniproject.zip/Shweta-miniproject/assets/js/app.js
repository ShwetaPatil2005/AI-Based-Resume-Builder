
const strRegex =  /^[a-zA-Z\s]*$/; 
const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

const digitRegex = /^\d+$/;

const mainForm = document.getElementById('cv-form');
const validType = {
    TEXT: 'text',
    TEXT_EMP: 'text_emp',
    EMAIL: 'email',
    DIGIT: 'digit',
    PHONENO: 'phoneno',
    ANY: 'any',
}


let firstnameElem = mainForm.firstname,
    middlenameElem = mainForm.middlename,
    lastnameElem = mainForm.lastname,
    imageElem = mainForm.image,
    designationElem = mainForm.designation,
    addressElem = mainForm.address,
    emailElem = mainForm.email,
    phonenoElem = mainForm.phoneno,
    summaryElem = mainForm.summary;

let nameDsp = document.getElementById('fullname_dsp'),
    imageDsp = document.getElementById('image_dsp'),
    phonenoDsp = document.getElementById('phoneno_dsp'),
    emailDsp = document.getElementById('email_dsp'),
    addressDsp = document.getElementById('address_dsp'),
    designationDsp = document.getElementById('designation_dsp'),
    summaryDsp = document.getElementById('summary_dsp'),
    projectsDsp = document.getElementById('projects_dsp'),
    achievementsDsp = document.getElementById('achievements_dsp'),
    skillsDsp = document.getElementById('skills_dsp'),
    educationsDsp = document.getElementById('educations_dsp'),
    experiencesDsp = document.getElementById('experiences_dsp');


const fetchValues = (attrs, ...nodeLists) => {
    let elemsAttrsCount = nodeLists.length;
    let elemsDataCount = nodeLists[0].length;
    let tempDataArr = [];

  
    for(let i = 0; i < elemsDataCount; i++){
        let dataObj = {};

        for(let j = 0; j < elemsAttrsCount; j++){
          
            dataObj[`${attrs[j]}`] = nodeLists[j][i].value;
        }
        tempDataArr.push(dataObj);
    }

    return tempDataArr;
}

const getUserInputs = () => {

   
    let achievementsTitleElem = document.querySelectorAll('.achieve_title'),
    achievementsDescriptionElem = document.querySelectorAll('.achieve_description');

  
    let expTitleElem = document.querySelectorAll('.exp_title'),
    expOrganizationElem = document.querySelectorAll('.exp_organization'),
    expLocationElem = document.querySelectorAll('.exp_location'),
    expStartDateElem = document.querySelectorAll('.exp_start_date'),
    expEndDateElem = document.querySelectorAll('.exp_end_date'),
    expDescriptionElem = document.querySelectorAll('.exp_description');


    let eduSchoolElem = document.querySelectorAll('.edu_school'),
    eduDegreeElem = document.querySelectorAll('.edu_degree'),
    eduCityElem = document.querySelectorAll('.edu_city'),
    eduStartDateElem = document.querySelectorAll('.edu_start_date'),
    eduGraduationDateElem = document.querySelectorAll('.edu_graduation_date'),
    eduDescriptionElem = document.querySelectorAll('.edu_description');

    let projTitleElem = document.querySelectorAll('.proj_title'),
    projLinkElem = document.querySelectorAll('.proj_link'),
    projDescriptionElem = document.querySelectorAll('.proj_description');

    let skillElem = document.querySelectorAll('.skill');

  
    firstnameElem.addEventListener('keyup', (e) => validateFormData(e.target, validType.TEXT, 'First Name'));
    middlenameElem.addEventListener('keyup', (e) => validateFormData(e.target, validType.TEXT_EMP, 'Middle Name'));
    lastnameElem.addEventListener('keyup', (e) => validateFormData(e.target, validType.TEXT, 'Last Name'));
    phonenoElem.addEventListener('keyup', (e) => validateFormData(e.target, validType.PHONENO, 'Phone Number'));
    emailElem.addEventListener('keyup', (e) => validateFormData(e.target, validType.EMAIL, 'Email'));
    addressElem.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Address'));
    designationElem.addEventListener('keyup', (e) => validateFormData(e.target, validType.TEXT, 'Designation'));

    achievementsTitleElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Title')));
    achievementsDescriptionElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Description')));
    expTitleElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Title')));
    expOrganizationElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Organization')));
    expLocationElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, "Location")));
    expStartDateElem.forEach(item => item.addEventListener('blur', (e) => validateFormData(e.target, validType.ANY, 'End Date')));
    expEndDateElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'End Date')));
    expDescriptionElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Description')));
    eduSchoolElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'School')));
    eduDegreeElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Degree')));
    eduCityElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'City')));
    eduStartDateElem.forEach(item => item.addEventListener('blur', (e) => validateFormData(e.target, validType.ANY, 'Start Date')));
    eduGraduationDateElem.forEach(item => item.addEventListener('blur', (e) => validateFormData(e.target, validType.ANY, 'Graduation Date')));
    eduDescriptionElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Description')));
    projTitleElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Title')));
    projLinkElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Link')));
    projDescriptionElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'Description')));
    skillElem.forEach(item => item.addEventListener('keyup', (e) => validateFormData(e.target, validType.ANY, 'skill')));

    return {
        firstname: firstnameElem.value,
        middlename: middlenameElem.value,
        lastname: lastnameElem.value,
        designation: designationElem.value,
        address: addressElem.value,
        email: emailElem.value,
        phoneno: phonenoElem.value,
        summary: summaryElem.value,
        achievements: fetchValues(['achieve_title', 'achieve_description'], achievementsTitleElem, achievementsDescriptionElem),
        experiences: fetchValues(['exp_title', 'exp_organization', 'exp_location', 'exp_start_date', 'exp_end_date', 'exp_description'], expTitleElem, expOrganizationElem, expLocationElem, expStartDateElem, expEndDateElem, expDescriptionElem),
        educations: fetchValues(['edu_school', 'edu_degree', 'edu_city', 'edu_start_date', 'edu_graduation_date', 'edu_description'], eduSchoolElem, eduDegreeElem, eduCityElem, eduStartDateElem, eduGraduationDateElem, eduDescriptionElem),
        projects: fetchValues(['proj_title', 'proj_link', 'proj_description'], projTitleElem, projLinkElem, projDescriptionElem),
        skills: fetchValues(['skill'], skillElem)
    }
};

function validateFormData(elem, elemType, elemName){
   
    if(elemType == validType.TEXT){
        if(!strRegex.test(elem.value) || elem.value.trim().length == 0) addErrMsg(elem, elemName);
        else removeErrMsg(elem);
    }

    
    if(elemType == validType.TEXT_EMP){
        if(!strRegex.test(elem.value)) addErrMsg(elem, elemName);
        else removeErrMsg(elem);
    }

   
    if(elemType == validType.EMAIL){
        if(!emailRegex.test(elem.value) || elem.value.trim().length == 0) addErrMsg(elem, elemName);
        else removeErrMsg(elem);
    }

   
    if(elemType == validType.PHONENO){
        if(!phoneRegex.test(elem.value) || elem.value.trim().length == 0) addErrMsg(elem, elemName);
        else removeErrMsg(elem);
    }

  
    if(elemType == validType.ANY){
        if(elem.value.trim().length == 0) addErrMsg(elem, elemName);
        else removeErrMsg(elem);
    }
}


function addErrMsg(formElem, formElemName){
    formElem.nextElementSibling.innerHTML = `${formElemName} is invalid`;
}


function removeErrMsg(formElem){
    formElem.nextElementSibling.innerHTML = "";
}


const showListData = (listData, listContainer) => {
    listContainer.innerHTML = "";
    listData.forEach(listItem => {
        let itemElem = document.createElement('div');
        itemElem.classList.add('preview-item');
        
        for(const key in listItem){
            let subItemElem = document.createElement('span');
            subItemElem.classList.add('preview-item-val');
            subItemElem.innerHTML = `${listItem[key]}`;
            itemElem.appendChild(subItemElem);
        }

        listContainer.appendChild(itemElem);
    })
}

const displayCV = (userData) => {
    nameDsp.innerHTML = userData.firstname + " " + userData.middlename + " " + userData.lastname;
    phonenoDsp.innerHTML = userData.phoneno;
    emailDsp.innerHTML = userData.email;
    addressDsp.innerHTML = userData.address;
    designationDsp.innerHTML = userData.designation;
    summaryDsp.innerHTML = userData.summary;
    showListData(userData.projects, projectsDsp);
    showListData(userData.achievements, achievementsDsp);
    showListData(userData.skills, skillsDsp);
    showListData(userData.educations, educationsDsp);
    showListData(userData.experiences, experiencesDsp);
}




const generateCV = () => {
    let userData = getUserInputs();
    displayCV(userData);
    console.log(userData);
}

function previewImage(){
    let oFReader = new FileReader();
    oFReader.readAsDataURL(imageElem.files[0]);
    oFReader.onload = function(ofEvent){
        imageDsp.src = ofEvent.target.result;
    }
}

//function downloadResume() {
    //const resumeContent = generateResumeContent();
    //const blob = new Blob([resumeContent], { type: 'text/html' });
   /* const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'resume.html'; // Change this to 'resume.pdf' if generating PDF
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}*/

/*function downloadResume(format) {
    if (format === 'html') {
        const resumeContent = generateResumeContent(); // Assuming this generates HTML content
        const blob = new Blob([resumeContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'resume.html'; 
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } else if (format === 'word') {
        const wordContent = generateWordContent(); // Function to generate Word content
        const blob = new Blob([wordContent], { type: 'application/msword' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'resume.doc'; 
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } else if (format === 'pdf') {
        generatePDF(); // Function to generate PDF
    }
}

function generateWordContent() {
    let userData = getUserInputs();
    let wordContent = `
        <html xmlns:w="urn:schemas-microsoft-com:office:word">
        <head>
            <meta charset="utf-8">
            <style>
                body { font-family: Arial, sans-serif; }
                h1, h2, h3 { color: #333; }
                .section { margin-bottom: 20px; }
            </style>
        </head>
        <body>
            <h1>${userData.firstname} ${userData.middlename} ${userData.lastname}</h1>
            <p><strong>Phone:</strong> ${userData.phoneno}</p>
            <p><strong>Email:</strong> ${userData.email}</p>
            <p><strong>Address:</strong> ${userData.address}</p>
            <p><strong>Designation:</strong> ${userData.designation}</p>
            <p><strong>Summary:</strong> ${userData.summary}</p>
            <div class="section">
                <h2>Projects</h2>
                ${userData.projects.map(project => `<p>${project.proj_title}: ${project.proj_description} (${project.proj_link})</p>`).join('')}
            </div>
            <div class="section">
                <h2>Achievements</h2>
                ${userData.achievements.map(achievement => `<p>${achievement.achieve_title}: ${achievement.achieve_description}</p>`).join('')}
            </div>
            <div class="section">
                <h2>Skills</h2>
                ${userData.skills.map(skill => `<p>${skill.skill}</p>`).join('')}
            </div>
            <div class="section">
                <h2>Education</h2>
                ${userData.educations.map(edu => `<p>${edu.edu_degree} from ${edu.edu_school}, ${edu.edu_city} (${edu.edu_start_date} - ${edu.edu_graduation_date})</p>`).join('')}
            </div>
            <div class="section">
                <h2>Experience</h2>
                ${userData.experiences.map(exp => `<p>${exp.exp_title} at ${exp.exp_organization}, ${exp.exp_location} (${exp.exp_start_date} - ${exp.exp_end_date})</p>`).join('')}
            </div>
        </body>
        </html>
    `;
    return wordContent;
}

function generatePDF() {
    const { jsPDF } = window.jspdf; // Use the jsPDF library
    const doc = new jsPDF();

    let userData = getUserInputs();
    
    doc.setFontSize(22);
    doc.text(`${ userData.firstname} ${userData.middlename} ${userData.lastname}`, 10, 10);
    doc.setFontSize(12);
    doc.text(`Phone: ${userData.phoneno}`, 10, 20);
    doc.text(`Email: ${userData.email}`, 10, 30);
    doc.text(`Address: ${userData.address}`, 10, 40);
    doc.text(`Designation: ${userData.designation}`, 10, 50);
    doc.text(`Summary: ${userData.summary}`, 10, 60);
    
    doc.text('Projects:', 10, 70);
    userData.projects.forEach((project, index) => {
        doc.text(`${index + 1}. ${project.proj_title}: ${project.proj_description} (${project.proj_link})`, 10, 80 + (index * 10));
    });

    doc.text('Achievements:', 10, 80 + (userData.projects.length * 10) + 10);
    userData.achievements.forEach((achievement, index) => {
        doc.text(`${index + 1}. ${achievement.achieve_title}: ${achievement.achieve_description}`, 10, 90 + (userData.projects.length * 10) + (index * 10));
    });

    doc.text('Skills:', 10, 90 + (userData.projects.length * 10) + (userData.achievements.length * 10) + 10);
    userData.skills.forEach((skill, index) => {
        doc.text(`${index + 1}. ${skill.skill}`, 10, 100 + (userData.projects.length * 10) + (userData.achievements.length * 10) + (index * 10));
    });

    doc.text('Education:', 10, 100 + (userData.projects.length * 10) + (userData.achievements.length * 10) + (userData.skills.length * 10) + 10);
    userData.educations.forEach((edu, index) => {
        doc.text(`${index + 1}. ${edu.edu_degree} from ${edu.edu_school}, ${edu.edu_city} (${edu.edu_start_date} - ${edu.edu_graduation_date})`, 10, 110 + (userData.projects.length * 10) + (userData.achievements.length * 10) + (userData.skills.length * 10) + (index * 10));
    });

    doc.text('Experience:', 10, 110 + (userData.projects.length * 10) + (userData.achievements.length * 10) + (userData.skills.length * 10) + (userData.educations.length * 10) + 10);
    userData.experiences.forEach((exp, index) => {
        doc.text(`${index + 1}. ${exp.exp_title} at ${exp.exp_organization}, ${exp.exp_location} (${exp.exp_start_date} - ${exp.exp_end_date})`, 10, 120 + (userData.projects.length * 10) + (userData.achievements.length * 10) + (userData.skills.length * 10) + (userData.educations.length * 10) + (index * 10));
    });

    doc.save('resume.pdf');
}*/


// Function to download resume as PDF
function downloadResumeAsPDF() {
    const element = document.getElementById('resume'); // Your resume element
    html2pdf()
        .from(element)
        .save('resume.pdf');
}

// Function to download resume as Word document
function downloadResumeAsWord() {
    const { Document, Packer, Paragraph, TextRun, HeadingLevel } = docx;

    // Create a new document
    const doc = new Document({
        sections: [{
            properties: {},
            children: [
                new Paragraph({
                    text: "Your Name", // Replace with dynamic content
                    heading: HeadingLevel.HEADING_1,
                }),
                new Paragraph({
                    text: "Contact Information: Phone, Email, Address", // Replace with dynamic content
                }),
                new Paragraph({
                    text: "Experience", // Section title
                    heading: HeadingLevel.HEADING_2,
                }),
                new Paragraph({
                    text: "Job Title at Company Name (Start Date - End Date)", // Replace with dynamic content
                }),
                new Paragraph({
                    text: "Job Description...", // Replace with dynamic content
                }),
                new Paragraph({
                    text: "Education", // Section title
                    heading: HeadingLevel.HEADING_2,
                }),
                new Paragraph({
                    text: "Degree from University Name (Year)", // Replace with dynamic content
                }),
                // Add more sections and content as needed
            ],
        }],
    });

    // Create a Packer to export the document
    Packer.toBlob(doc).then((blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'resume.docx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url); // Clean up
    });
}

function printCV(){
    window.print();
}