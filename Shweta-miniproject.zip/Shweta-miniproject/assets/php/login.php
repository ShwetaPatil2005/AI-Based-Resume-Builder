<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
    <title>Log In - AI Based Resume Builder</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4e9f7;  
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background: #fdfdfd;
            display: flex;
            flex-direction: column;
            padding: 30px;
            border-radius: 30px;
            width: 300px;
            box-shadow: 0 0 100 0 rgba(0, 0, 0, 0.1), 
                        0 32px 64px -48px rgba(0, 0, 0, 0.1);
        }

        .login-container h2 {
            text-align: center;
            color: rgba(76,68,182,0.808);
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: rgba(76,68,182,0.808);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            opacity: 0.82;
        }
        .submit{
            width: 100%;
        }

        .signup-link {
            text-align: center;
            margin-top: 10px;
            margin-bottom: 15px;
        }

        .signup-link a {
            color:rgba(76,68,182,0.808);
            text-decoration: none;
        }

        .message {
            text-align: center;
            color: red;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>Log In</h2>
        <?php
           include('configu.php');
           if (isset($_POST['submit'])) {
              $username = mysqli_real_escape_string($con, $_POST['username']);
              $password = mysqli_real_escape_string($con, $_POST['password']);

              $result = mysqli_query($con, "SELECT * FROM users WHERE Username = '$username' AND Password='$password'")
              or die("Error!!");

              $row = mysqli_fetch_assoc($result);

              if (is_array($row) && !empty($row)) {
                $_SESSION['valid'] = $row['Email'];
                $_SESSION['username'] = $row['Username'];
                $_SESSION['user_id'] = $row['id']; // Corrected session variable

                header("Location: second.php");
                exit();
              } else {
                echo "<div class='message'>
                          <p>Wrong Username or Password!!</p>
                      </div> <br>";
                echo "<a href='login.php'><button class='btn'>Go Back</button></a>";
              }
           } else {
        ?>
        <form id="loginForm" method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="submit">Log In</button>
        </form>
        <div class="signup-link">
            <p>Don't have an account? <a href="signup.php"><u>Sign Up</u></a></p>
        </div>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            // Prevent the form from submitting the default way
            // event.preventDefault();

            // Redirect to second.php after successful login
            // window.location.href = 'second.php';
        });
    </script>
    <?php } ?>
</body>
</html>
