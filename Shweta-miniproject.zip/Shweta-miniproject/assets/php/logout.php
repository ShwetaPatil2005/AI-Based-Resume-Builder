<?php
session_start();

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column; /* Stack elements vertically */
            align-items: center; /* Center horizontally */
            height: 100vh; /* Full viewport height */
        }

        .header { 
            color: white;
            padding: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%; /* Full width header */
            position: relative; /* Position relative for stacking context */
        }

        .header h1 {
            background-color: rgba(76, 68, 182, 0.808);
            color: white;
            display: inline-block;
            padding: 20px 50px;
            border-radius: 5px;
            font-size: 1.5em;
            margin: 0;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px; /* Fixed width for better layout */
            margin-top: 200px; /* Add space between header and container */
             /* Allow the container to take available space */
            display: flex; /* Use flexbox for centering content inside */
            flex-direction: column; /* Stack content vertically */
            justify-content: center; /* Center content vertically */
        }

        h2 {
            color: #555;
            margin: 0px;
        }

        button {
            background-color: rgba(76,68,182,0.808);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            margin-top: 20px;
        }

        button:hover {
            background-color:  rgba(76,68,182,0.808);
        }

        a {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color:  rgba(76,68,182,0.808);
            font-size: 16px;
            transition: color 0.3s;
        }

        a:hover {
            color:  rgba(76,68,182,0.808);
        }

        /* Responsive design */
        @media (max-width: 600px) {
            body {
                padding: 20px;
            }

            .container {
                width: 90%; /* Responsive width */
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Logout</h1>
    </div>
    <div class="container">
        <h2>Are you sure you want to log out?</h2>
        <form action="process_logout.php" method="POST" onsubmit="return confirmLogout();"> 
            <button type="submit" onclick="window.location.href='process_logout.php'">Yes, Log Out</button>
        </form>
        <a href="index.php"><u>Cancel</u></a>
    </div>

    <script>
        function confirmLogout() {
            return confirm("Are you sure you want to log out?");
        }
    </script>
</body>
</html>