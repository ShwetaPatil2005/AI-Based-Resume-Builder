<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e9ecef;
            color: #343a40;
        }

        .header { 
            color: white;
            padding: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: relative; /* Ensure the header is positioned relative */
        }

        .header h1 {
            background-color: rgba(76,68,182,0.808);
            color: white;
            display: inline-block;
            padding: 20px 50px;
            border-radius: 5px;
            font-size: 1.5em;
            margin: 0;
        }

        .container {
            max-width: 500px;
            margin: 30px auto;
            margin-top: 70px; /* Ensure there's enough space below the header */
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: rgba(76,68,182,0.808);
        }

        label {
            margin-top: 10px;
            display: block;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        textarea:focus {
            border-color: rgba(76,68,182,0.808);
            outline: none;
        }

        input[type="file"] {
            margin-top: 10px;
        }

        button {
            background-color: rgba(76,68,182,0.808);
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgba(76,68,182,0.5);
        }

        .profile-picture {
            display: block;
            margin: 20px auto;
            border-radius: 50%;
            width: 100px;
            height: 100px;
            object-fit: cover;
            border: 2px solid rgba(76,68,182,0.808);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        .file-input-label {
            display: inline-block;
            margin-top: 10px;
            padding: 10px;
            background-color: rgba(76,68,182,0.808);
            color: white;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            transition: background-color 0.3s;
        }

        .file-input-label:hover {
            background-color: rgba(76,68,182,0.5);
        }

        #profile-picture {
            display: none; /* Hide the default file input */
        }

    </style>
</head>
<body>
    <div class="header">
        <h1>User Profile</h1>
    </div>
    <div class="container">
        <h2>Create or Update Your Profile</h2>
        <form action="save_profile.php" method="post" enctype="multipart/form-data">
            <label for="profile-picture" class="file-input-label">Upload Profile Picture</label>
            <input type="file" id="profile-picture" name="profile_picture" accept="image/*" onchange="previewImage(event)">
            <img id="preview" class="profile-picture" src="#" alt="Profile Picture" style="display:none;">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" required>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
            <label for="bio">Bio</label>
            <textarea id="bio" name="bio" rows="4"></textarea>
            <button type="submit">Save Profile</button>
        </form>
    </div>
    <script>
        function previewImage(event) {
            const preview = document.getElementById('preview');
            const file = event.target.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            if (file) {
                reader.readAsDataURL(file);
            }
        }

        
    </script>
</body>
</html>
