<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Builder</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.5/gsap.min.js"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #eaeaea; /* Neutral background color */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333; /* Dark text color for contrast */
        }

        .container {
            display: flex;
            justify-content: space-between;
            width: 100%;
            max-width: 800px;
            padding: 20px;
        }

        .box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            flex: 1;
            margin: 10px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex; /* Use flexbox */
            flex-direction: column; /* Arrange children in a column */
            justify-content: center; /* Center children vertically */
            align-items: center; /* Center children horizontally */
        }

        .box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            width: 100%;
            font-size: 1.8em;
        }

        ul {
            list-style-type: none;
            padding: 0;
            margin: 10px 0;
            color: #555;
        }

        li {
            margin: 5px 0;
        }

        .button {
            display: block;
            padding: 15px;
            margin: 10px 0;
            background-color: #28a745; /* Green button color */
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            cursor: pointer; /* Change cursor to pointer */
        }

        .button:hover {
            background-color: #218838; /* Darker green on hover */
        }

        /* Hide the file input */
        #file-input {
            display: none;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="box">
            <h1>Create Fresh Resume</h1>
            <ul>
                <li>Build from scratch</li>
                <li>User-friendly interface</li>
                <li>Multiple templates available</li>
            </ul>
            <a href="resume.php" class="button">Start Fresh</a>
        </div>
        <div class="box">
            <h1>Update Your Current Resume</h1>
            <ul>
                <li>Keep it up-to-date</li>
                <li>Easily edit existing content</li>
                <li>Download in various formats</li>
            </ul>
            <button class="button" id="upload-button">Choose File</button>
            <input type="file" id="file-input" />
        </div>
    </div>

    <script>
        // GSAP Animation
        gsap.from(".container", { duration: 1, opacity: 0, y: -50 });
        gsap.from(".box", { duration: 0.5, opacity: 0, y: 20, stagger: 0.2 });

        // JavaScript to trigger file input
        document.getElementById('upload-button').addEventListener('click', function() {
            document.getElementById('file-input').click();
        });

        // Optional: Handle file selection
        document.getElementById('file-input').addEventListener('change', function(event) {
            const fileName = event.target.files[0] ? event.target.files[0].name : 'No file chosen';
            alert(`Selected file: ${fileName}`);
        });
    </script>
</body>
</html>