<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - AI Based Resume Builder</title>
    <style>
        /* Your CSS styling */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4e9f7;
            display: flex;
            justify-content: center; 
            align-items: center;
            height: 100vh;
        }

        .signup-container {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .signup-container h2 {
            text-align: center;
            color: rgba(76,68,182,0.808);
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color:rgba(76,68,182,0.808);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgba(76,68,182,0.808);
        }

        .login-link {
            text-align: center;
            margin-top: 10px;
        }

        .login-link a {
            color: rgba(76,68,182,0.808);
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Sign Up</h2>
        <?php
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        include("configu.php");

        if (isset($_POST['Sign_up'])) {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];

            // Verifying the unique email
            $verify_query = mysqli_query($con, "SELECT Email FROM users WHERE Email = '$email'");

            if (mysqli_num_rows($verify_query) != 0) {
                echo "<div class='message'>
                          <p>This email is used, Try another One Please!</p>
                      </div> <br>";
                echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button></a>";
            } else {
                $insert_query = "INSERT INTO users (Username, Email, Password) VALUES ('$username','$email','$password')";
                if (mysqli_query($con, $insert_query)) {
                    echo "<div class='message'>
                              <p>Registration Successfully Done!</p>
                          </div> <br>";
                    echo "<a href='changeProfile.php'><button class='btn'>Update your profile</button></a>";
                } else {
                    echo "Error: " . $insert_query . "<br>" . mysqli_error($con);
                }
            }
        } else {
        ?>

        <form id="signupForm" method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="Sign_up">Sign Up</button>
        </form>
        <div class="login-link">
            <p>Already have an account? <a href="login.php"><u>Log In</u></a></p>
        </div>
    </div>

    <script>
        document.getElementById('signupForm').addEventListener('submit', function(event) {
            // Prevent the form from submitting the default way
            // event.preventDefault();

            // Redirect to login.php after successful signup
            // window.location.href = 'login.php';
        });
    </script>
    <?php } ?>
</body>
</html>
