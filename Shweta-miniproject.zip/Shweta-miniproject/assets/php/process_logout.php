<?php
session_start();
session_unset();
session_destroy();

// Redirect to index.php with a success message
header("Location: index.php?message=success");
exit();
?>
