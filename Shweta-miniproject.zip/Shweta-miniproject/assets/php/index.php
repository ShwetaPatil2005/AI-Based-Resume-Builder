<?php
session_start();
include('configu.php');
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Based Resume Builder</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700&family=Roboto:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Your existing styles here */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            background-image: url('https://img.freepik.com/free-vector/blue-white-gradient-abstract-background_53876-62620.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            transition: background-color 0.3s;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #B7B7B7;
            color:  #fff5d7;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
            font-family: 'Roboto Slab', serif;
        }

        .nav-icon {
            display: flex;
            align-items: center;
            cursor: pointer;
            margin-right: 10px;
            transition: transform 0.3s;
        }

        .nav-icon:hover {
            transform: translateX(-5px);
        }

        .nav-dropdown {
            position: relative;
            display: inline-block;
        }

        .nav-dropdown-content {
            color:black;
            display: none;
            position: absolute;
            background-color: #ffffff;
            min-width: 200px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1;
            padding: 15px;
            border-radius: 8px;
            top: 50px; /* Position below the icon */
            right: 0; /* Align to the left side */
        }

        .nav-dropdown.show .nav-dropdown-content {
            display: block;
        }

        .nav-link {
            color: black;
            text-decoration: none;
            display: block;
            padding: 10px;
            transition: background-color 0.3s, color 0.3s;
        }

        .nav-link:hover {
            background-color: #007bff;
            color: white;
        }

        .about-tooltip {
            display: none;
            position: absolute;
            background-color:  #f0f0f0;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            top: 50px; /* Positioning the tooltip */
            left: 0; /* Aligning it below the button */
            z-index: 20;
            width: 250px; /* Set a width for the tooltip */
        }

        .container {
            display: flex;
            justify-content: center;
            padding: 20px;
            margin-top: 10px;
            flex-wrap: wrap;
        }

        .content {
            flex: 1;
            padding: 20px;
            max-width: 500px;
            margin: 10px;
        }

        .content h2 {
            color: #333;
            font-size: 28px;
        }

        .content p {
            line-height: 1.6;
        }

        .resume-image {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
        }

        .hiw-container {
            padding: 40px 20px;
            text-align: center;
            background-attachment: fixed;
        }

        .items-list {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .item {
            position: relative; /* Needed for overlay */
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden; /* Ensures overlay does not overflow */
            flex: 1;
            max-width: 400px; 
            margin: 10px;
            transition: transform 0.3s, background-color 0.3s; /* Added transition for background color */
            background-color: #f0f0f0; /* Set background color to white */
        }

        .item:hover {
            transform: scale(1.05);
            background-color: white; /* Change background color on hover */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); /* Add shadow on hover */
        }

        .item h2, .item p {
            position: relative; /* Position text above overlay */
            z-index: 1; /* Ensure text appears above the overlay */
            color: black; /* Change text color for better visibility */
            justify-content: center;
            display: flex;
            text-align: center; /* Center text */
        }

        .features {
            display: flex;
            justify-content: center;
            margin-top: 40px;
            flex-wrap: wrap;
        }

        .feature-box {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 200px;
            margin: 10px;
            transition: transform 0.3s;
        }

        .feature-box:hover {
            transform: scale(1.05);
            background-color: #f0f0f0; /* Change background color on hover */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); /* Add shadow on hover */
        }

        .get-started {
            display: block;
            width: 200px;
            margin: 40px auto;
            padding: 10px;
            text-align: center;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .get-started:hover {
            background-color: #0056b3;
        }

        .testimonial-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
            flex-wrap: wrap;
        }

        .testimonial {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin: 10px;
            transition: transform 0.3s;
            max-width: 300px;
            text-align: center;
        }

        .testimonial:hover {
            transform: scale(1.02);
            background-color: #f0f0f0; /* Change background color on hover */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); /* Add shadow on hover */
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>AI Based Resume Builder</h1>
        <div class="nav-dropdown">
            <div class="nav-icon" onclick="toggleDropdown()">
                <i class="fas fa-bars" style="font-size: 24px;"></i>
            </div>
            <div class="nav-dropdown-content" id="navDropdownContent">
                <a href="javascript:void(0)" onmouseover="showAbout()" onmouseout="hideAbout()" class="nav-link">About Us</a>
                <div class="about-tooltip" id="aboutTooltip">
                    <h3 style="color: black;">About Us</h3>
                    <p style="color: black;">We are dedicated to helping job seekers create professional resumes that highlight their skills and experiences. Our AI technology ensures that your resume is tailored to meet the demands of today's job market.</p>
                </div>
                <a href="login.php" class="nav-link">Log In</a>
                <a href="signup.php" class="nav-link">Sign Up</a>
                <a href="changeProfile.php" class="nav-link">Create Profile</a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="content">
            <h2 style="font-size: 32px; font-weight: bold;">Welcome to the AI Based Resume Builder!</h2>
            <p style="font-size: 20px;">Crafting a perfect resume has never been easier. Our AI-driven platform helps you build a professional resume that stands out.</p>
            <h3 style="font-size: 24px; margin-top: 20px;">How It Works</h3>
            <ul style="font-size: 20px; list-style: none; padding: 0;">
                <li><i class="fas fa-clock"></i> Save time using prewritten bullet points crafted by resume experts</li>
                <li><i class="fas fa-pencil-alt"></i> Select a recruiter-approved template that will get your resume noticed.</li>
                <li><i class="fas fa-file-download"></i> Download or print your new resume!</li>
            </ul>
        </div>
        <div class="im">
            <img src="https://marketplace.canva.com/EAFToMa2lws/2/0/283w/canva-black-and-white-simple-office-assistant-resume-pCr-yRbsrMY.jpg" alt="Sample Resume" class="resume-image">
        </div>
    </div>
    
    <section class="hiw-container" id="hiwContainer">
        <h2 class="phoenix-h2 hiw-title">Create a resume in minutes</h2>
        <div class="items-list">
            <div class="item effortless">
                <h2 class="phoenix-h2">Effortless</h2>
                <p class="subheadline">Easy to use with a step-by-step wizard that guides you through choosing the right words to use in each section.</p>
            </div>
            <div class="item cutting-edge">
                <h2 class="phoenix-h2">Cutting-edge</h2>
                <p class="subheadline">Our state-of-the-art technology helps you complete a stand-out resume easily and quickly.</p>
            </div>
            <div class="item powerful">
                <h2 class="phoenix-h2">Powerful</h2>
                <p class="subheadline">Your resume will showcase your greatest strengths, talents, and accomplishments.</p>
            </div>
        </div>
    </section>
    
    <div class="features">
        <h3>Features</h3>
        <div class="feature-box">AI-Driven Suggestions</div>
        <div class="feature-box">Customizable Templates</div>
        <div class="feature-box">Real-Time Formatting</div>
        <div class="feature-box">Downloadable Formats (PDF, Word)</div>
    </div>

    <div class="testimonial-container">
        <h3 style="text-align: center;">What Our Users Say</h3>
        <div class="testimonial">
            <p><i>"This resume builder made my job search so much easier! I landed an interview within a week!" - Sarah J.</i></p>
        </div>
        <div class="testimonial">
            <p><i>"The templates are beautiful and easy to customize. Highly recommend!" - Mark T.</i></p>
        </div>
    </div>

    <a href="login.php" class="get-started">Get Started</a>
    
    <script>
        function toggleDropdown() {
            const dropdown = document.querySelector('.nav-dropdown');
            dropdown.classList.toggle('show');
        }

        function showAbout() {
            document.getElementById('aboutTooltip').style.display = 'block';
        }

        function hideAbout() {
            document.getElementById('aboutTooltip').style.display = 'none';
        }

        window.onload = function() { 
            const urlParams = new URLSearchParams(window.location.search); 
            const message = urlParams.get('message'); 
            if (message === 'profile_saved') { 
                alert('Profile saved successfully.'); 
            }
        }
    </script>

</body>
</html>
