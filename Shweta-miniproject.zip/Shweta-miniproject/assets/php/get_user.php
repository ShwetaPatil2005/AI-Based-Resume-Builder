<?php
// Database connection parameters
$host = 'localhost';
$db = 'tutorial'; // Your database name
$user = 'root'; // Default XAMPP MySQL username
$pass = ''; // Default XAMPP MySQL password is empty

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

// Get user ID from the request
$userId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Prepare and execute the query
$query = "SELECT * FROM users WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':id', $userId, PDO::PARAM_INT);

try {
    $stmt->execute();
    $user_profile = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user_profile) {
        // Return the user profile as JSON
        header('Content-Type: application/json');
        echo json_encode($user_profile);
    } else {
        // Return a 404 status code if the user is not found
        http_response_code(404);
        echo json_encode(['error' => 'User not found']);
    }
} catch (PDOException $e) {
    // Return a 500 status code for database errors
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
