<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .signup-container {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .signup-container h2 {
            text-align: center;
            color: rgba(76,68,182,0.808);
        }
        button {
            width: 100%;
            padding: 10px;
            background-color:rgba(76,68,182,0.808);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgba(76,68,182,0.808);
        }
    </style>
</head>
<body>
    <div class='signup-container'>
        <?php
    include('configu.php'); // Ensure this path is correct

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if user ID is set in the session
    if (!isset($_SESSION['user_id'])) {
        echo "User not logged in.";
        exit;
    }

    // Get user ID from session
    $user_id = $_SESSION['user_id'];

    // Ensure $con is initialized
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get form inputs and escape them for security
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $bio = mysqli_real_escape_string($con, $_POST['bio']);

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $profile_picture = $_FILES['profile_picture'];
        $upload_dir = 'uploads/';
        $upload_file = $upload_dir . basename($profile_picture['name']);
        
        // Create uploads directory if it doesn't exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        if (move_uploaded_file($profile_picture['tmp_name'], $upload_file)) {
            $profile_picture_path = $upload_file;
        } else {
            echo "Error uploading file.";
            exit;
        }
    } else {
        $profile_picture_path = null;
    }

    // Insert or update user profile in the database
    $query = "INSERT INTO user_profiles (user_id, name, username, email, bio, profile_picture)
              VALUES ('$user_id', '$name', '$username', '$email', '$bio', '$profile_picture_path')
              ON DUPLICATE KEY UPDATE
              name='$name', username='$username', email='$email', bio='$bio', profile_picture='$profile_picture_path'";
    
    if (mysqli_query($con, $query)) {
        // Redirect to index.php with a success message
        //header("Location: index.php?message=profile_saved");
        //exit();
        echo "<div class='message'>
                              <p>Profile updated Successfully!</p>
                          </div> <br>";
                    echo "<a href='login.php'><button class='btn'>Login Now</button></a>";
    } else {
        echo "Error: " . mysqli_error($con);
    }

    // Close the database connection
    mysqli_close($con);
}
?>
    </div>
</body>
</html>
